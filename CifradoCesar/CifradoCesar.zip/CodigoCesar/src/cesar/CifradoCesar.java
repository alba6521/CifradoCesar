package cesar;
import java.util.Scanner;
public class CifradoCesar {

	public static void main(String[] args) {

		Scanner leer = new Scanner(System.in);

		System.out.print("Introduce el mensaje: ");
		String texto = leer.nextLine();

		System.out.print("Introduce la clave de desplazamiento: ");
		int clave = leer.nextInt();

		String textoCifrado = cifrar(texto, clave);
		String textoDescifrado = cifrar(textoCifrado, -clave);

		System.out.println("\nTexto original: " + texto);
		System.out.println("Texto cifrado: " + textoCifrado);
		System.out.println("Texto descifrado: " + textoDescifrado);

		leer.close();
	}

	public static String cifrar(String texto, int clave) {

		String resultado = "";

		for (int i = 0; i < texto.length(); i++) {

			char caracter = texto.charAt(i);
			if (Character.isLetter(caracter)) {

				char base;
				if (Character.isUpperCase(caracter)) {
					base = 'A';
				} else {
					base = 'a';
				}
				int posicion = caracter - base;
				int nuevaPosicion = (posicion + clave) % 26;

				if (nuevaPosicion < 0) {
					nuevaPosicion += 26;
				}
				caracter = (char) (base + nuevaPosicion);
			}
			resultado += caracter;
		}

		return resultado;
	}
}